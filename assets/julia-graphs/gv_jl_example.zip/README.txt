This is sample code discussed in my note about graph
visualization with Julia and Graphviz
at https://www.bochkarev.io/tools/julia-graphs/

The archive contains the following files besides this README.txt:
- graphviz_example.jl - Julia source code from the note,
- example.tex - sample file to test the LaTeX distribution
                (must compile successfully with "lualatex example.tex")
- example.pdf - expected output (PDF)
